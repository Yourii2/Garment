<?php
// منع الوصول المباشر
header('HTTP/1.0 403 Forbidden');
exit('Access denied');
?>