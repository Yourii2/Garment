<nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
    <div class="position-sticky pt-3">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="<?= BASE_URL ?>/dashboard.php">
                    <i class="fas fa-tachometer-alt me-2"></i>لوحة التحكم
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?= BASE_URL ?>/production/manufacturing_stages.php">
                    <i class="fas fa-cogs me-2"></i>مراحل التصنيع
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?= BASE_URL ?>/inventory/invoices.php">
                    <i class="fas fa-file-invoice me-2"></i>فواتير المخزون
                </a>
            </li>
        </ul>
    </div>
</nav>