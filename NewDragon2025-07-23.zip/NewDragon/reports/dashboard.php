<?php
// تقارير وإحصائيات النظام
include_once '../includes/auth.php';
requireLogin();

// إحصائيات المستخدمين، النشاطات، إلخ
?>